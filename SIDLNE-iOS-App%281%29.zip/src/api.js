import * as SecureStore from 'expo-secure-store';
const BASE = (process.env.EXPO_PUBLIC_API_URL || '').replace(/\/$/, '');
export const privacyUrl = BASE + '/privacy';
export const supportUrl = BASE + '/support';
let token = null;
export const configured = !!BASE && (BASE.startsWith('https://') || (__DEV__ && BASE.startsWith('http://')));
export async function restoreSession() { token = await SecureStore.getItemAsync('sidlne-session'); return !!token; }
export async function saveSession(value) { await SecureStore.setItemAsync('sidlne-session', value); token = value; }
export async function clearSession() { token = null; await SecureStore.deleteItemAsync('sidlne-session'); }
export async function api(path, method = 'GET', body) {
  if (!configured) throw new Error('SIDLNE needs its secure server address before it can connect.');
  const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 90000);
  try {
    const response = await fetch(BASE + path, { method, signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const data = await response.json();
    if (!response.ok) {
      const error = new Error(typeof data.detail === 'string' ? data.detail : 'Check the information you entered and try again.');
      error.status = response.status; throw error;
    }
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The server took too long to respond. Please try again.');
    if (error.message === 'Network request failed') throw new Error('Unable to connect. Check your internet connection.');
    throw error;
  } finally { clearTimeout(timeout); }
}
