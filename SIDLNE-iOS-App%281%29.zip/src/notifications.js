import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { api } from './api';
let pushToken = null;
Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }) });
export async function enableNotifications() {
  const projectId = Constants.expoConfig?.extra?.eas?.projectId || Constants.easConfig?.projectId;
  if (!projectId) throw new Error('Notifications require a signed iPhone build connected to your Expo project.');
  const permission = await Notifications.requestPermissionsAsync();
  if (permission.status !== 'granted') throw new Error('Notifications are disabled. You can enable SIDLNE in iPhone Settings.');
  pushToken = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  await api('/push-token', 'POST', { token: pushToken });
}
export async function detachNotifications() {
  try {
    const projectId = Constants.expoConfig?.extra?.eas?.projectId || Constants.easConfig?.projectId;
    if (!pushToken && projectId && (await Notifications.getPermissionsAsync()).status === 'granted') pushToken = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
    if (pushToken) await api('/push-token', 'DELETE', { token: pushToken });
  } catch {} finally { pushToken = null; }
}
