# SIDLNE 1.1 — connected family iPhone app

This replaces the local public demo with a working client/server application. It has been tested locally and bundled for iOS. It has NOT been deployed, installed on a physical iPhone, signed as an IPA, or submitted to Apple. Hosting, email, Expo/APNs credentials and real calendar-feed testing remain required.

## What works in the code

- Adult email/password accounts, scrypt password hashes, 30-day revocable sessions, iPhone Keychain session storage.
- One private family per account; owner-managed, rotating 7-day invite codes (up to 10 joins); member removal revokes all open invites.
- Shared month/week schedule, manual events with actual dates and local times, Apple Maps links, team/athlete labels.
- Private calendar subscription imports (webcal/HTTPS) for enabled SportsEngine and Sports Connect domains. Recurrence, EXDATE, moved occurrences, cancellations, time zones and all-day dates are handled. The server checks feeds every 15 minutes; foreground phones refresh shared state every 5 seconds.
- Shared family chat (latest 300 messages displayed), ride offers, atomic one-seat reservations, release/cancellation.
- Optional push notifications for messages, ride offers, new events and changed feed schedules. Private details are not included in notification previews. Requires a signed physical-device build, Expo project ID and APNs setup. Delivery integration is implemented; delivery to an actual phone is unverified.
- SMTP password reset codes (30 minutes, one use), session revocation on reset, in-app account deletion.
- Server-side persisted SQLite database, deployment files, privacy/support endpoints, 14 backend integration tests.

## Quick local run (developer)

Use Python 3.12+ and a supported Node LTS version. From the project folder:

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r server/requirements.txt
cd server
python -m uvicorn app:app --host 0.0.0.0 --port 8000 --no-access-log
```

In another terminal, from the project folder:

```sh
npm ci
cp .env.example .env
# Set EXPO_PUBLIC_API_URL to http://YOUR-COMPUTER-LAN-IP:8000 for local development.
npx expo start
```

Simulator: `http://localhost:8000`. A physical phone must be on the same network and use the computer's LAN address. HTTP is allowed only in development; signed release builds require HTTPS. Expo Go does not verify native push notifications; use a development/TestFlight build for those. Never expose the development HTTP server publicly.

Create an account, create a family, connect a calendar, and invite another independently registered account. The second phone receives the same family data from the server. No sample people, private feed tokens, or family password are embedded in the package.

## Easiest hosted route

`render.yaml` provides a managed Docker web service with a persistent disk. Upload this project to a private Git repository, connect that repository to a Render Blueprint, and set the requested email variables. This provisions paid hosting; review the provider's current price before creating it. Set SUPPORT_EMAIL as a server environment variable. Use the assigned HTTPS URL as EXPO_PUBLIC_API_URL when building the app. Keep one instance and one API worker; SQLite storage is not intended for a multi-instance deployment.

Alternatively, `compose.yaml` deploys the API and Caddy HTTPS on your own server. Set a domain in the root `.env`, copy `server/.env.example` to `server/.env`, configure email/support, point the domain to the server, and run `docker compose up -d --build`. Only the HTTPS proxy is publicly exposed. Back up the SQLite database using its online backup API, and encrypt/retain backups according to the published policy. Test restore before inviting real users.

## iPhone / TestFlight

1. Supply the real HTTPS API address in the build environment; it is public configuration, never a secret.
2. Sign in to the owner's Expo account with `npx eas-cli login`.
3. Run `npx eas-cli init` to associate the app with the owner's project and populate the EAS project ID.
4. Run `npx eas-cli build:configure`. Keep bundle ID `app.sidlne.mobile` only if available in the owner's Apple account.
5. Set `EXPO_PUBLIC_API_URL` in the appropriate EAS environment or build profile. Rebuild after changing it.
6. Run `npx eas-cli build --platform ios --profile production`, signing with the owner's Apple Developer account. Configure APNs credentials when prompted.
7. Run `npx eas-cli submit --platform ios --profile production`, then complete TestFlight setup in App Store Connect.
8. Install via TestFlight and test two real phones before App Store review.

Never put SMTP_PASSWORD or EXPO_ACCESS_TOKEN in EXPO_PUBLIC_* variables or app.json. Expo push security is optional; if enabled in Expo, set its access token on the server. Production EAS builds are configured with the production environment. These instructions are handoff steps, not a claim that accounts or credentials have already been configured.

## Launch checks still required

Verify real subscription URLs from each provider (some providers redirect or use additional domains), two-phone synchronization, locked-phone notifications, password recovery email, feed failures and cancellations, deletion/revocation, accessibility and layouts on actual iPhones. This environment had no Apple signing credentials, physical iPhone or Docker daemon, so signed/native/container checks remain outstanding.

The feed fetcher requires approved HTTPS hosts, validates all resolved addresses as public, pins the connection to a validated address, verifies TLS, disallows redirects, and limits responses to 2 MB. Enable any additional provider domain only after review. Feed URLs remain on the server; filesystem/disk encryption must be enabled by the hosting operator. Imported schedules cover the previous 30 days and next 365 days; feed imports are snapshots and removed events also remove attached rides.

SMTP recovery requires your email provider's configuration. Accounts are not email-verified yet; possession of a private invite gates access to family data. One reservation represents one adult account's single seat, rather than separate child seats. Family chat is family-scoped, with no team-wide public chat or moderation system. Notifications are best effort; retries are bounded, and Expo ticket acceptance does not establish delivery on a phone. There are no payments, analytics, ads, or tracking SDKs. Public release still needs operational/security review and app-store metadata review.

## Verification

```sh
python3 -m unittest discover -s server/tests -v
npx expo export --platform ios
npx expo-doctor
```

See BUILD_VERIFICATION.md for actual results, and APP_STORE_LISTING.md for draft store copy.
