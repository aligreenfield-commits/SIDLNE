# Ali — what happens next

The demo has been upgraded into connected app code. It now needs a home online and an Apple-signed build before you can use it on your phone.

**This ZIP is the project, not an installable iPhone app.** No app has been published yet.

The simplest launch path is:

1. Connect a hosting account for the shared server, and an email service for password recovery.
2. Connect your Expo account and Apple Developer membership for SIDLNE LLC.
3. Build and install through Apple's TestFlight.
4. Create your account, create your family, paste your calendar subscription links, and invite Logan or a friend.

You do not need to invent a family password: every adult gets their own password, and the family owner shares a private invitation code. The app generates it when you tap Invite family.

An account owner or developer still needs to complete the setup in README.md. No private sports calendar link has been embedded in this public package. Existing website access codes do not transfer to this new account system.
