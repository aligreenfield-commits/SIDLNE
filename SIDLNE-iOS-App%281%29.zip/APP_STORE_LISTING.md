# Draft listing — SIDLNE 1.1

Name: SIDLNE
Subtitle: Your family’s sports calendar
Proposed bundle ID: app.sidlne.mobile (owner must confirm availability)
Category: Lifestyle / Sports

## Description
Every practice, game, ride, and family update in one place.

Create a private family, connect your supported sports calendar subscription links, and keep everyone on the same schedule. Switch between week and month views, add family events, offer rides, reserve a seat, and message your family.

SIDLNE periodically checks connected calendars for changes and keeps your family's schedule together across phones. Optional notifications let you know about messages, rides and schedule updates.

Each adult has their own account. Private invitation codes help you bring the right people into your family space.

## Before submitting
- Supply actual screenshots from the signed app and real support contact.
- Host the API. Use its live /privacy and /support pages as the store URLs.
- Configure password-recovery email and push notifications.
- Create a private review family with fictional data and working reviewer credentials. Do not embed those credentials in the public source.
- Verify deletion, two-device sync, real calendar imports and notifications.
- Complete App Privacy disclosures based on actual hosting, email, Expo and Apple data processing: account email/name and user ID, family-provided content (schedules/messages/rides), device push token and authentication data. There are no analytics/advertising SDKs. Review the final labels with Apple's current questionnaire.
- Accounts are for adults. Review age rating and child-data policy before release.

This is draft metadata; nothing has been submitted or approved.
