import React, { useEffect, useState } from 'react';
import {
  Alert,
  AppState,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  FlatList,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { enableNotifications, detachNotifications } from './src/notifications';
import { api, privacyUrl, supportUrl, configured, restoreSession, saveSession, clearSession } from './src/api';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

const C = {
  ink: '#141814', paper: '#f7f7f2', white: '#ffffff', lime: '#c6f566',
  moss: '#66774b', sage: '#e9efe0', line: '#dfe3da', muted: '#74796f', blue: '#dae9ff', coral: '#ffd9c9',
};

const DAY = 86400000;
const startToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const iso = (d) => d.toISOString();
const addDays = (n, hour = 17, minute = 30) => { const d = startToday(); d.setDate(d.getDate() + n); d.setHours(hour, minute, 0, 0); return iso(d); };

const eventDate = (value) => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(...value.split('-').map((v,i)=>Number(v)-(i===1?1:0))) : new Date(value);
const formatDay = (value, long = false) => eventDate(value).toLocaleDateString([], long
  ? { weekday: 'long', month: 'long', day: 'numeric' }
  : { weekday: 'short', month: 'short', day: 'numeric' });
const formatTime = (value) => new Date(value).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
const sameDate = (a, b) => eventDate(a).toDateString() === eventDate(b).toDateString();

function Pill({ children, active, onPress }) {
  return <Pressable onPress={onPress} style={[styles.pill, active && styles.pillActive]}><Text style={[styles.pillText, active && styles.pillTextActive]}>{children}</Text></Pressable>;
}

function Header({ title, subtitle, onShare }) {
  return <View style={styles.header}>
    <View style={{ flex: 1 }}><Text style={styles.brand}>SIDLNE /</Text><Text style={styles.pageTitle}>{title}</Text>{subtitle ? <Text style={styles.subtle}>{subtitle}</Text> : null}</View>
    {onShare ? <Pressable accessibilityRole="button" onPress={onShare} style={styles.circleButton}><Text style={styles.circleText}>↗</Text></Pressable> : null}
  </View>;
}

function EventCard({ item }) {
  const openMap = () => Linking.openURL(`https://maps.apple.com/?q=${encodeURIComponent(item.location)}`);
  return <View style={styles.eventCard}>
    <View style={[styles.eventStripe, { backgroundColor: item.color || C.lime }]} />
    <View style={{ flex: 1 }}>
      <Text style={styles.eventTime}>{formatDay(item.start)} · {item.all_day ? 'All day' : formatTime(item.start)}</Text>
      <Text style={styles.eventTitle}>{item.title}</Text>
      <Text style={styles.eventMeta}>{item.athlete} · {item.team}</Text>
      <Pressable onPress={openMap}><Text style={styles.location}>⌖ {item.location}</Text></Pressable>
    </View>
  </View>;
}

function Overview({ events, onAdd, onShare, familyName }) {
  const next = [...events].filter(x => eventDate(x.start) >= startToday()).sort((a, b) => eventDate(a.start) - eventDate(b.start));
  return <ScrollView contentContainerStyle={styles.scroll}>
    <Header title="Family HQ" subtitle={familyName} onShare={onShare} />
    <View style={styles.hero}>
      <Text style={styles.eyebrow}>UP NEXT</Text>
      <Text style={styles.heroTitle}>{next[0] ? next[0].title : 'Your next play starts here.'}</Text>
      {next[0] ? <><Text style={styles.heroMeta}>{formatDay(next[0].start, true)} at {formatTime(next[0].start)}</Text><Text style={styles.heroMeta}>⌖ {next[0].location}</Text></> : null}
      <Pressable onPress={onAdd} style={styles.limeButton}><Text style={styles.limeButtonText}>＋ Add event</Text></Pressable>
    </View>
    <View style={styles.stats}>
      <View><Text style={styles.eyebrowDark}>THE NEXT 7 DAYS</Text><Text style={styles.statNumber}>{next.filter(x => eventDate(x.start) < new Date(Date.now() + 7 * DAY)).length}</Text></View>
      <View><Text style={styles.statLabel}>events in the lineup</Text><Text style={styles.statTiny}>{new Set(events.map(e => e.team).filter(Boolean)).size} teams · {new Set(events.map(e => e.athlete).filter(Boolean)).size} athletes</Text></View>
    </View>
    <SectionTitle title="Coming up" detail="Shared family schedule" />
    {next.slice(0, 4).map(item => <EventCard key={item.id} item={item} />)}
  </ScrollView>;
}

function SectionTitle({ title, detail }) {
  return <View style={styles.sectionTitle}><Text style={styles.sectionHeading}>{title}</Text>{detail ? <Text style={styles.subtle}>{detail}</Text> : null}</View>;
}

function CalendarScreen({ events }) {
  const [mode, setMode] = useState('Month');
  const [selected, setSelected] = useState(startToday());
  const monthStart = new Date(selected.getFullYear(), selected.getMonth(), 1);
  const gridStart = new Date(monthStart); gridStart.setDate(1 - monthStart.getDay());
  const days = Array.from({ length: 42 }, (_, i) => { const d = new Date(gridStart); d.setDate(gridStart.getDate() + i); return d; });
  const weekStart = new Date(selected); weekStart.setDate(selected.getDate() - selected.getDay());
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(weekStart.getDate() + i); return d; });
  const visibleDays = mode === 'Month' ? days : week;
  const selectedEvents = events.filter(x => sameDate(x.start, selected));
  const move = (n) => { const d = new Date(selected); if (mode === 'Week') d.setDate(d.getDate() + 7 * n); else { const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); } setSelected(d); };
  return <ScrollView contentContainerStyle={styles.scroll}>
    <Header title="Calendar" subtitle="Your family’s own sports calendar." />
    <View style={styles.segment}><Pill active={mode === 'Week'} onPress={() => setMode('Week')}>Week</Pill><Pill active={mode === 'Month'} onPress={() => setMode('Month')}>Month</Pill></View>
    <View style={styles.monthHeader}><Pressable onPress={() => move(-1)}><Text style={styles.arrow}>‹</Text></Pressable><Text style={styles.sectionHeading}>{selected.toLocaleDateString([], { month: 'long', year: 'numeric' })}</Text><Pressable onPress={() => move(1)}><Text style={styles.arrow}>›</Text></Pressable></View>
    <View style={styles.weekLabels}>{['S','M','T','W','T','F','S'].map((x, i) => <Text key={i} style={styles.weekLabel}>{x}</Text>)}</View>
    <View style={styles.calendarGrid}>{visibleDays.map((d, i) => {
      const has = events.some(x => sameDate(x.start, d)); const active = sameDate(d, selected); const muted = mode === 'Month' && d.getMonth() !== selected.getMonth();
      return <Pressable key={i} onPress={() => setSelected(d)} style={[styles.dayCell, mode === 'Week' && styles.weekDayCell, active && styles.dayCellActive]}>
        <Text style={[styles.dayText, muted && styles.dayMuted, active && styles.dayTextActive]}>{d.getDate()}</Text>{has ? <View style={[styles.dot, active && { backgroundColor: C.ink }]} /> : null}
      </Pressable>;
    })}</View>
    <SectionTitle title={formatDay(selected, true)} detail={`${selectedEvents.length} event${selectedEvents.length === 1 ? '' : 's'}`} />
    {selectedEvents.length ? selectedEvents.map(x => <EventCard item={x} key={x.id} />) : <Empty text="No events scheduled. Enjoy the open space." />}
  </ScrollView>;
}

function Button({ children, onPress, disabled, secondary }) {
  return <Pressable accessibilityRole="button" onPress={onPress} disabled={disabled} style={[secondary ? styles.smallButton : styles.limeButton, { marginTop: 14 }, disabled && { opacity: .45 }]}><Text style={secondary ? styles.smallButtonText : styles.limeButtonText}>{children}</Text></Pressable>;
}
function Field({ label, value, onChangeText, secret, placeholder, keyboardType }) {
  return <><Text style={styles.label}>{label}</Text><TextInput accessibilityLabel={label} value={value} onChangeText={onChangeText} secureTextEntry={secret} autoCapitalize="none" autoCorrect={false} placeholder={placeholder} keyboardType={keyboardType} style={styles.formInput}/></>;
}
function LegalLinks() { return configured ? <View style={{flexDirection:'row',gap:24,marginTop:24}}><Pressable onPress={()=>Linking.openURL(privacyUrl).catch(()=>Alert.alert('Unable to open privacy policy'))}><Text style={styles.link}>Privacy</Text></Pressable><Pressable onPress={()=>Linking.openURL(supportUrl).catch(()=>Alert.alert('Unable to open support'))}><Text style={styles.link}>Support</Text></Pressable></View> : null; }
function Empty({ text }) { return <View style={styles.empty}><Text style={styles.emptyText}>{text}</Text></View>; }

function Access({ onLogin }) {
  const [mode, setMode] = useState('Sign in'); const [name, setName] = useState('');
  const [code,setCode] = useState('');
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      if(mode==='Reset password') { await api('/auth/reset','POST',{code,password});setMode('Sign in');setCode('');setPassword('');Alert.alert('Password updated','Sign in with your new password.');return; }
      const data = await api(mode === 'Sign in' ? '/auth/login' : '/auth/register', 'POST', { name, email, password }); await saveSession(data.token); await onLogin(); }
    catch (error) { Alert.alert('Could not sign in', error.message); }
    finally { setBusy(false); }
  };
  return <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scroll}>
    <Header title="Less scramble. More sideline." subtitle="One shared home for your family’s sports life."/>
    {!configured ? <View style={styles.notice}><Text style={styles.noticeTitle}>Getting connected</Text><Text style={styles.noticeText}>Your app’s secure server has not been configured yet. This build cannot connect until setup is complete.</Text></View> : null}
    <View style={styles.segment}>{['Sign in', 'Create account', 'Reset password'].map(x => <Pill key={x} active={mode === x} onPress={() => setMode(x)}>{x==='Reset password'?'Reset':x}</Pill>)}</View>
    {mode === 'Create account' ? <Field label="YOUR NAME" value={name} onChangeText={setName}/> : null}
    {mode==='Reset password'?<><Field label="EMAIL" value={email} onChangeText={setEmail} keyboardType="email-address"/><Button secondary disabled={busy||!email} onPress={async()=>{setBusy(true);try{const r=await api('/auth/forgot','POST',{email});Alert.alert('Check your email',r.message);}catch(e){Alert.alert('Recovery unavailable',e.message);}finally{setBusy(false);}}}>Email me a reset code</Button><Field label="RESET CODE" value={code} onChangeText={setCode}/></>:<Field label="EMAIL" value={email} onChangeText={setEmail} keyboardType="email-address"/>}
    <Field label="PASSWORD · AT LEAST 10 CHARACTERS" value={password} onChangeText={setPassword} secret/>
    <Button disabled={busy || !configured || !email || password.length < 10 || (mode === 'Create account' && !name.trim()) || (mode==='Reset password'&&!code)} onPress={submit}>{busy ? 'Connecting…' : mode}</Button>
    <Text style={[styles.subtle, { marginTop: 24 }]}>Each adult gets their own account. Join the same family with a private invite code.</Text><LegalLinks/>
  </ScrollView></KeyboardAvoidingView>;
}

function Onboard({ run, reload, logout }) {
  const [name, setName] = useState(''); const [code, setCode] = useState(''); const [busy,setBusy]=useState(false);
  const go = async (path, body) => { setBusy(true); await run(async () => { await api(path,'POST',body); await reload(); }); setBusy(false); };
  return <ScrollView contentContainerStyle={styles.scroll}><Header title="Your family starts here." subtitle="Create a private space or join an existing family."/>
    <Field label="FAMILY NAME" value={name} onChangeText={setName} placeholder="Greenfield family"/>
    <Button disabled={busy || !name.trim()} onPress={() => go('/families',{name})}>Create family</Button>
    <SectionTitle title="Have an invite?"/>
    <Field label="PRIVATE INVITE CODE" value={code} onChangeText={setCode}/>
    <Button disabled={busy || !code.trim()} onPress={() => go('/families/join',{code})}>Join family</Button>
    <Button secondary onPress={logout}>Sign out</Button>
  </ScrollView>;
}

function FamilyScreen({ data, user, run, refresh, logout, openForm, removeAccount }) {
  const invite = () => run(async () => { const result = await api('/invites','POST'); await Share.share({ message: `Join ${data.family} on SIDLNE. Create your own account, tap Join family, and enter this private code: ${result.code}. It expires in 7 days. Share only with your family.` }); });
  const remove = (f) => Alert.alert('Remove calendar?', 'Its imported events and attached rides will be removed for everyone.', [{text:'Cancel',style:'cancel'},{text:'Remove',style:'destructive',onPress:()=>run(async()=>{await api('/feeds/'+f.id,'DELETE');await refresh();})}]);
  const manual = data.events.filter(e=>!e.feed_id);
  return <ScrollView contentContainerStyle={styles.scroll}><Header title="Family & teams" subtitle={data.family}/>
    <SectionTitle title="Your people"/>{data.members.map(m=><View key={m.id} style={styles.teamCard}><Text style={styles.eventTitle}>{m.name}</Text><Text style={styles.subtle}>{m.role === 'owner' ? 'Family owner' : 'Member'}</Text>{user.role==='owner'&&m.id!==user.id?<Pressable onPress={()=>Alert.alert('Remove '+m.name+'?','They will lose access and all open invite codes will be revoked.',[{text:'Cancel'},{text:'Remove',style:'destructive',onPress:()=>run(async()=>{await api('/members/'+m.id,'DELETE');await refresh();})}])}><Text style={styles.link}>Remove</Text></Pressable>:null}</View>)}
    {user.role==='owner' ? <Button onPress={invite}>Invite family</Button> : null}
    <SectionTitle title="Connected calendars" detail="Server checks every 15 minutes"/>
    {!data.feeds.length ? <Empty text="Paste a SportsEngine or Sports Connect calendar subscription link to get started."/> : null}
    {data.feeds.map(f=><View key={f.id} style={styles.teamCard}><View style={{flex:1}}><Text style={styles.eventTitle}>{f.name}</Text><Text style={styles.subtle}>{f.athlete}</Text><Text style={styles.subtle}>{f.synced ? 'Updated '+new Date(f.synced*1000).toLocaleString() : 'Waiting for first import'}</Text>{f.error ? <Text style={styles.noticeText}>{f.error}</Text>:null}
      {user.role==='owner' ? <View style={{flexDirection:'row',gap:12}}><Button secondary onPress={()=>run(async()=>{await api('/feeds/'+f.id+'/sync','POST');await refresh();})}>Refresh</Button><Button secondary onPress={()=>remove(f)}>Remove</Button></View>:null}</View></View>)}
    {user.role==='owner' ? <Button onPress={()=>openForm('feed')}>＋ Connect calendar</Button>:null}
    <SectionTitle title="Family events"/>
    {manual.map(e=><View key={e.id}><EventCard item={e}/>{user.role==='owner' ? <Pressable onPress={()=>Alert.alert('Delete event?','This also removes rides linked to it.',[{text:'Cancel'},{text:'Delete',style:'destructive',onPress:()=>run(async()=>{await api('/events/'+e.id,'DELETE');await refresh();})}])}><Text style={styles.link}>Delete {e.title}</Text></Pressable>:null}</View>)}
    <Button onPress={()=>run(async()=>{await enableNotifications();Alert.alert('Notifications enabled','We’ll let you know about family messages, ride offers, and calendar updates.');})}>Enable notifications</Button>
    <Button secondary onPress={logout}>Sign out</Button>
    <Button secondary onPress={removeAccount}>Delete my account</Button>
    <Text style={[styles.subtle,{marginTop:12}]}>Calendar links are private. Only family members can view your schedule and messages.</Text><LegalLinks/>
  </ScrollView>;
}

function RidesScreen({ rides, user, run, refresh, openForm }) {
  return <ScrollView contentContainerStyle={styles.scroll}><Header title="Rides" subtitle="Make room for your sideline crew."/><Button onPress={()=>openForm('ride')}>＋ Offer a ride</Button>
    {!rides.length ? <Empty text="No rides offered yet. Add an event, then offer a ride."/> : null}
    {rides.map(r=><View key={r.id} style={[styles.rideCard,{marginTop:14}]}><Text style={styles.eyebrowDark}>{r.event}</Text><Text style={styles.eventTitle}>{r.driver} is driving</Text><Text style={styles.eventMeta}>{r.route}</Text><Text style={styles.seats}>{r.remaining} seats open</Text>
      {r.user_id === user.id ? <Button secondary onPress={()=>run(async()=>{await api('/rides/'+r.id,'DELETE');await refresh();})}>Cancel offer</Button> : <Button disabled={!r.claimed && !r.remaining} onPress={()=>run(async()=>{await api('/rides/'+r.id+'/claim',r.claimed?'DELETE':'POST');await refresh();})}>{r.claimed ? 'Release my seat' : 'Claim one seat'}</Button>}
    </View>)}
  </ScrollView>;
}

function ChatScreen({ messages, user, run, refresh }) {
  const [draft,setDraft]=useState(''); const [busy,setBusy]=useState(false);
  const send=async()=>{if(!draft.trim()||busy)return;setBusy(true);await run(async()=>{await api('/messages','POST',{body:draft.trim()});setDraft('');await refresh();});setBusy(false);};
  return <KeyboardAvoidingView style={styles.chatPage} behavior={Platform.OS==='ios'?'padding':undefined}><Header title="Family chat" subtitle="Shared with the people in your family."/>
    <FlatList data={messages} keyExtractor={x=>x.id} contentContainerStyle={styles.chatList} ListEmptyComponent={<Empty text="Start your family’s first conversation."/>} renderItem={({item})=><View style={[styles.message,item.user_id===user.id&&styles.messageMine]}><Text style={styles.messageAuthor}>{item.author} · {new Date(item.created*1000).toLocaleString()}</Text><Text style={styles.messageBody}>{item.body}</Text></View>}/>
    <View style={styles.composer}><TextInput accessibilityLabel="Family message" value={draft} onChangeText={setDraft} maxLength={2000} placeholder="Message the family…" style={styles.input}/><Pressable accessibilityLabel="Send message" disabled={busy || !draft.trim()} onPress={send} style={styles.send}><Text style={styles.sendText}>{busy?'…':'↑'}</Text></Pressable></View>
  </KeyboardAvoidingView>;
}

function FormModal({ kind, close, submit, events, busy }) {
  const [values,setValues]=useState({timezone:'America/New_York',date:[new Date().getFullYear(),String(new Date().getMonth()+1).padStart(2,'0'),String(new Date().getDate()).padStart(2,'0')].join('-'),time:'17:30',seats:'3'});
  const field=(key,label,placeholder,secret=false)=><Field key={key} label={label} value={values[key]||''} onChangeText={v=>setValues({...values,[key]:v})} placeholder={placeholder} secret={secret}/>;
  const save=()=>{
    if(kind==='event') {
      const parts=(values.date||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);const clock=(values.time||'').match(/^(\d{2}):(\d{2})$/);
      if(!parts||!clock)return Alert.alert('Check the date','Use YYYY-MM-DD and a 24-hour time such as 17:30.');
      const [year,month,day]=parts.slice(1).map(Number);const [hour,minute]=clock.slice(1).map(Number);const d=new Date(year,month-1,day,hour,minute);
      if(d.getFullYear()!==year||d.getMonth()!==month-1||d.getDate()!==day||hour>23||minute>59||d.getHours()!==hour||d.getMinutes()!==minute)return Alert.alert('Check the date','Enter a valid date and time.');
      submit('/events',{title:values.title||'',athlete:values.athlete||'',team:values.team||'Family',location:values.location||'',start:d.toISOString()});
    } else if(kind==='feed')submit('/feeds',{name:values.name||'',athlete:values.athlete||'',url:values.url||'',timezone:values.timezone});
    else if(kind==='ride')submit('/rides',{event_id:values.event_id||'',seats:Number(values.seats),route:values.route||''});
    else submit('/account',{password:values.password||''},'DELETE');
  };
  return <Modal visible animationType="slide" presentationStyle="pageSheet" onRequestClose={close}><SafeAreaView style={styles.modalPage}><View style={styles.modalHeader}><Pressable disabled={busy} onPress={close}><Text style={styles.link}>Cancel</Text></Pressable><Text style={styles.sectionHeading}>{({event:'New event',feed:'Connect calendar',ride:'Offer a ride',delete:'Delete account'})[kind]}</Text></View>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.form}>
      {kind==='event'?<>{field('title','EVENT NAME','Practice, game, meet…')}{field('athlete','ATHLETE')}{field('team','TEAM')}{field('location','LOCATION')}{field('date','DATE · YYYY-MM-DD')}{field('time','LOCAL TIME · HH:MM','17:30')}<Text style={styles.subtle}>Uses your phone’s time zone.</Text></>:null}
      {kind==='feed'?<>{field('name','TEAM / CALENDAR NAME')}{field('athlete','ATHLETE')}{field('url','CALENDAR SUBSCRIPTION LINK','webcal://…')}{field('timezone','TIME ZONE','America/New_York')}<Text style={styles.subtle}>Use a calendar subscription link, rather than a team webpage. SportsEngine and Sports Connect providers are enabled.</Text></>:null}
      {kind==='ride'?<><Text style={styles.label}>CHOOSE EVENT</Text>{events.filter(e=>eventDate(e.start)>=startToday()).map(e=><Pill key={e.id} active={values.event_id===e.id} onPress={()=>setValues({...values,event_id:e.id})}>{e.title} · {formatDay(e.start)}</Pill>)}{field('seats','AVAILABLE SEATS · 1 TO 8')}{field('route','ROUTE','Home → Field')}</>:null}
      {kind==='delete'?<><Text style={styles.noticeText}>Deleting your account is permanent. If you own the family, its calendars, events, chat, and rides are deleted for everyone. Other members keep their own accounts.</Text>{field('password','CONFIRM YOUR PASSWORD','',true)}</>:null}
      <Button disabled={busy} onPress={save}>{busy?'Saving…':kind==='delete'?'Permanently delete':'Save'}</Button>
    </ScrollView></SafeAreaView></Modal>;
}

const tabs=[{k:'Home',i:'⌂'},{k:'Calendar',i:'▦'},{k:'Family',i:'◉'},{k:'Rides',i:'↗'},{k:'Chat',i:'●'}];
function Main() {
  const [tab,setTab]=useState('Home');const [user,setUser]=useState(null);const [data,setData]=useState(null);const [loading,setLoading]=useState(true);const [form,setForm]=useState(null);const [busy,setBusy]=useState(false);const [connection,setConnection]=useState('');
  const refreshing=React.useRef(false);const generation=React.useRef(0);
  const logout=async()=>{generation.current++;await detachNotifications();try{await api('/auth/logout','POST');}catch{}await clearSession();setUser(null);setData(null);setForm(null);setConnection('');};
  const load=async()=>{
    const version=generation.current;
    try{const me=await api('/me');const state=me.family_id?await api('/state'):null;if(version!==generation.current)return;setUser(me);setData(state);setConnection('');}
    catch(error){if(version!==generation.current)return;if(error.status===401){await clearSession();setUser(null);setData(null);}else{setConnection(error.message);throw error;}}
  };
  const refresh=async()=>{
    if(refreshing.current)return;refreshing.current=true;const version=generation.current;
    try{const state=await api('/state');if(version!==generation.current)return;setData(state);setConnection('');}
    catch(error){if(version!==generation.current)return;if(error.status===401){await clearSession();setUser(null);setData(null);}else if(error.status===409){await load();}else{setConnection(error.message);throw error;}}
    finally{refreshing.current=false;}
  };
  const run=async(fn)=>{try{await fn();return true;}catch(error){Alert.alert('Could not complete',error.message);return false;}};
  useEffect(()=>{(async()=>{try{if(await restoreSession())await load();}catch(error){Alert.alert('Connection unavailable',error.message);}finally{setLoading(false);}})();},[]);
  useEffect(()=>{if(!user?.family_id)return;const tick=()=>{if(AppState.currentState==='active')refresh().catch(()=>{});};const interval=setInterval(tick,5000);const listener=AppState.addEventListener('change',state=>{if(state==='active')tick();});return()=>{clearInterval(interval);listener.remove();};},[user?.family_id]);
  const submit=async(path,body,method='POST')=>{if(busy)return;setBusy(true);await run(async()=>{await api(path,method,body);setForm(null);if(path==='/account'){generation.current++;await clearSession();setUser(null);setData(null);}else await refresh();});setBusy(false);};
  const share=()=>{if(user.role==='owner')run(async()=>{const r=await api('/invites','POST');await Share.share({message:`Join ${data.family} on SIDLNE. Create an account and enter invite code ${r.code}. Expires in 7 days. Keep this private.`});});else Alert.alert('Invite family','Ask your family owner for an invite code.');};
  let body;
  if(loading)body=<View style={{flex:1,justifyContent:'center',alignItems:'center'}}><ActivityIndicator size="large"/><Text style={styles.subtle}>Opening your sideline…</Text></View>;
  else if(!user)body=<Access onLogin={load}/>;
  else if(!user.family_id)body=<Onboard run={run} reload={load} logout={logout}/>;
  else if(!data)body=<View style={styles.scroll}><Empty text="Waiting for your family schedule."/><Button onPress={()=>run(load)}>Try again</Button><Button secondary onPress={logout}>Sign out</Button></View>;
  else if(tab==='Calendar')body=<CalendarScreen events={data.events}/>;
  else if(tab==='Family')body=<FamilyScreen data={data} user={user} run={run} refresh={refresh} logout={logout} openForm={setForm} removeAccount={()=>setForm('delete')}/>;
  else if(tab==='Rides')body=<RidesScreen rides={data.rides} user={user} run={run} refresh={refresh} openForm={setForm}/>;
  else if(tab==='Chat')body=<ChatScreen messages={data.messages} user={user} run={run} refresh={refresh}/>;
  else body=<Overview events={data.events} onAdd={()=>setForm('event')} onShare={share} familyName={data.family}/>;
  return <SafeAreaProvider><StatusBar style="dark"/><SafeAreaView style={styles.app}>{connection?<Pressable onPress={()=>run(load)} style={{padding:12,backgroundColor:C.coral}}><Text>Connection unavailable. Tap to retry.</Text></Pressable>:null}<View style={{flex:1}}>{body}</View>{user?.family_id&&data?<View style={styles.tabbar}>{tabs.map(t=><Pressable accessibilityLabel={t.k} key={t.k} onPress={()=>setTab(t.k)} style={styles.tab}><Text style={[styles.tabIcon,tab===t.k&&styles.tabActive]}>{t.i}</Text><Text style={[styles.tabText,tab===t.k&&styles.tabActive]}>{t.k}</Text></Pressable>)}</View>:null}{form?<FormModal key={form} kind={form} close={()=>setForm(null)} submit={submit} events={data?.events||[]} busy={busy}/>:null}</SafeAreaView></SafeAreaProvider>;
}
export default Main;

const styles = StyleSheet.create({
  app:{ flex:1, backgroundColor:C.paper }, scroll:{ padding:20, paddingBottom:40 }, header:{ flexDirection:'row', alignItems:'center', marginBottom:22 }, brand:{ fontSize:12, fontWeight:'900', letterSpacing:2.2, color:C.moss, marginBottom:5 }, pageTitle:{ fontSize:34, lineHeight:39, fontWeight:'900', color:C.ink, letterSpacing:-1 }, subtle:{ color:C.muted, fontSize:14, marginTop:3 }, circleButton:{ width:46,height:46,borderRadius:23,backgroundColor:C.white,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:C.line },circleText:{fontSize:24,color:C.ink},
  hero:{ backgroundColor:C.ink,borderRadius:28,padding:24,marginBottom:14 },eyebrow:{fontSize:12,fontWeight:'900',letterSpacing:2,color:C.lime,marginBottom:18},heroTitle:{fontSize:34,lineHeight:40,fontWeight:'800',letterSpacing:-1,color:C.white,marginBottom:12},heroMeta:{color:'#d9ddd4',fontSize:16,lineHeight:24},limeButton:{alignSelf:'flex-start',backgroundColor:C.lime,borderRadius:14,paddingHorizontal:18,paddingVertical:13,marginTop:22},limeButtonText:{color:C.ink,fontSize:16,fontWeight:'800'},
  stats:{backgroundColor:C.sage,borderRadius:22,padding:20,flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:24},eyebrowDark:{fontSize:11,fontWeight:'900',letterSpacing:1.4,color:C.moss},statNumber:{fontSize:55,fontWeight:'900',lineHeight:60,color:C.ink},statLabel:{fontSize:16,color:C.moss,fontWeight:'700',maxWidth:120},statTiny:{fontSize:12,color:C.muted,marginTop:7},sectionTitle:{marginTop:10,marginBottom:12},sectionHeading:{fontSize:21,fontWeight:'900',color:C.ink},
  eventCard:{backgroundColor:C.white,borderRadius:18,padding:16,marginBottom:11,flexDirection:'row',gap:14,borderWidth:1,borderColor:C.line},eventStripe:{width:6,borderRadius:3},eventTime:{fontSize:12,fontWeight:'800',color:C.moss,textTransform:'uppercase',marginBottom:4},eventTitle:{fontSize:19,fontWeight:'800',color:C.ink},eventMeta:{fontSize:14,color:C.muted,marginTop:4},location:{fontSize:14,color:'#476b2c',fontWeight:'700',marginTop:8},
  pill:{paddingVertical:9,paddingHorizontal:19,borderRadius:20},pillActive:{backgroundColor:C.ink},pillText:{color:C.muted,fontWeight:'800'},pillTextActive:{color:C.lime},segment:{alignSelf:'flex-start',backgroundColor:'#e7e8e1',borderRadius:24,padding:3,flexDirection:'row',marginBottom:18},monthHeader:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:12},arrow:{fontSize:35,color:C.moss,paddingHorizontal:10},weekLabels:{flexDirection:'row'},weekLabel:{width:'14.285%',textAlign:'center',fontSize:11,fontWeight:'900',color:C.muted,paddingVertical:8},calendarGrid:{flexDirection:'row',flexWrap:'wrap',marginBottom:14},dayCell:{width:'14.285%',height:48,alignItems:'center',justifyContent:'center',borderRadius:15},weekDayCell:{height:66},dayCellActive:{backgroundColor:C.lime},dayText:{fontWeight:'700',color:C.ink},dayMuted:{color:'#b9bcb4'},dayTextActive:{fontWeight:'900'},dot:{width:5,height:5,borderRadius:3,backgroundColor:C.moss,marginTop:4},
  teamCard:{backgroundColor:C.white,borderRadius:20,padding:16,marginBottom:12,flexDirection:'row',alignItems:'center',gap:14,borderWidth:1,borderColor:C.line},teamBadge:{width:52,height:52,borderRadius:18,alignItems:'center',justifyContent:'center'},teamBadgeText:{fontSize:24,fontWeight:'900',color:C.ink},notice:{backgroundColor:'#fff4ee',borderColor:'#efd4c7',borderWidth:1,borderRadius:18,padding:17,marginTop:12},noticeTitle:{fontSize:16,fontWeight:'900',color:'#884c35',marginBottom:5},noticeText:{color:'#7b594c',lineHeight:20},
  rideCard:{backgroundColor:C.white,borderRadius:22,padding:19,marginBottom:12,borderWidth:1,borderColor:C.line},rideFooter:{marginTop:16,paddingTop:14,borderTopWidth:1,borderTopColor:C.line,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},seats:{fontWeight:'800',color:C.moss},smallButton:{backgroundColor:C.ink,borderRadius:12,paddingHorizontal:14,paddingVertical:10},smallButtonText:{color:C.white,fontWeight:'800'},
  chatPage:{flex:1,paddingHorizontal:20,backgroundColor:C.paper},chatList:{paddingVertical:10,gap:10},message:{alignSelf:'flex-start',maxWidth:'84%',backgroundColor:C.white,borderRadius:18,borderBottomLeftRadius:5,padding:14,borderWidth:1,borderColor:C.line},messageMine:{alignSelf:'flex-end',backgroundColor:C.lime,borderColor:'#a8d249',borderBottomLeftRadius:18,borderBottomRightRadius:5},messageAuthor:{fontSize:11,fontWeight:'900',color:C.moss,marginBottom:5},messageBody:{fontSize:16,lineHeight:22,color:C.ink},composer:{flexDirection:'row',gap:8,paddingVertical:10,borderTopWidth:1,borderTopColor:C.line},input:{flex:1,backgroundColor:C.white,borderRadius:20,paddingHorizontal:16,paddingVertical:12,fontSize:16,borderWidth:1,borderColor:C.line},send:{width:46,height:46,borderRadius:23,backgroundColor:C.ink,alignItems:'center',justifyContent:'center'},sendText:{color:C.lime,fontSize:24,fontWeight:'900'},
  empty:{borderWidth:1,borderStyle:'dashed',borderColor:'#cbd0c6',borderRadius:18,padding:26,alignItems:'center'},emptyText:{color:C.muted,textAlign:'center'},tabbar:{flexDirection:'row',backgroundColor:C.white,borderTopWidth:1,borderTopColor:C.line,paddingTop:8,paddingBottom:9},tab:{flex:1,alignItems:'center'},tabIcon:{fontSize:20,color:'#a4a8a0',height:24},tabText:{fontSize:10,fontWeight:'800',color:'#999e95'},tabActive:{color:C.moss},
  modalPage:{flex:1,backgroundColor:C.paper},modalHeader:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',padding:20,borderBottomWidth:1,borderBottomColor:C.line},link:{fontSize:16,fontWeight:'800',color:C.moss},form:{padding:20},label:{fontSize:11,fontWeight:'900',letterSpacing:1.5,color:C.moss,marginBottom:7,marginTop:14},formInput:{backgroundColor:C.white,borderWidth:1,borderColor:C.line,borderRadius:15,padding:15,fontSize:17},
});
