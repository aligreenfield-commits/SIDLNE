import sys, tempfile, unittest, socket
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app as backend
from fastapi.testclient import TestClient

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();backend.DB=self.tmp.name+'/test.db';backend.init();self.client=TestClient(backend.app)
        self.a=self.register('a');self.b=self.register('b');self.other=self.register('other')
        self.client.post('/families',headers=self.a,json={'name':'A family'})
        self.client.post('/families',headers=self.other,json={'name':'Other family'})
    def tearDown(self):self.tmp.cleanup()
    def register(self,name):
        r=self.client.post('/auth/register',json={'name':name,'email':name+'@example.com','password':'test-password-123'})
        self.assertEqual(r.status_code,200,r.text);return {'Authorization':'Bearer '+r.json()['token']}
    def join(self):
        code=self.client.post('/invites',headers=self.a).json()['code']
        r=self.client.post('/families/join',headers=self.b,json={'code':code});self.assertEqual(r.status_code,200)
    def event(self):
        r=self.client.post('/events',headers=self.a,json={'title':'Game','start':'2026-10-10T14:00:00-04:00','location':'Field'})
        self.assertEqual(r.status_code,200,r.text);return r.json()['id']
    def test_auth_and_family_isolation(self):
        self.assertEqual(self.client.get('/state').status_code,401)
        id=self.event();self.assertEqual(len(self.client.get('/state',headers=self.other).json()['events']),0)
        r=self.client.post('/rides',headers=self.other,json={'event_id':id,'seats':1,'route':'Field'});self.assertEqual(r.status_code,404)
        login=self.client.post('/auth/login',json={'email':'a@example.com','password':'wrong-password'});self.assertEqual(login.status_code,401)
        self.client.post('/auth/logout',headers=self.a);self.assertEqual(self.client.get('/me',headers=self.a).status_code,401)
    def test_invites_rotation_and_roles(self):
        old=self.client.post('/invites',headers=self.a).json()['code'];new=self.client.post('/invites',headers=self.a).json()['code']
        self.assertEqual(self.client.post('/families/join',headers=self.b,json={'code':old}).status_code,400)
        self.assertEqual(self.client.post('/families/join',headers=self.b,json={'code':new}).status_code,200)
        self.assertEqual(self.client.post('/invites',headers=self.b).status_code,403)
        self.assertEqual(self.client.post('/families/join',headers=self.b,json={'code':new}).status_code,409)
    def test_shared_chat_and_atomic_seats(self):
        self.join();id=self.event()
        self.assertEqual(self.client.post('/messages',headers=self.a,json={'body':'Hello family'}).status_code,200)
        self.assertEqual(self.client.get('/state',headers=self.b).json()['messages'][0]['body'],'Hello family')
        ride=self.client.post('/rides',headers=self.a,json={'event_id':id,'seats':1,'route':'Home → Field'}).json()['id']
        for i in range(2):self.assertEqual(self.client.post('/rides/'+ride+'/claim',headers=self.b).status_code,200)
        r=self.client.get('/state',headers=self.b).json()['rides'][0];self.assertEqual(r['remaining'],0);self.assertTrue(r['claimed'])
        third=self.register('third');code=self.client.post('/invites',headers=self.a).json()['code'];self.client.post('/families/join',headers=third,json={'code':code})
        self.assertEqual(self.client.post('/rides/'+ride+'/claim',headers=third).status_code,409)
        self.client.delete('/rides/'+ride+'/claim',headers=self.b);self.assertEqual(self.client.post('/rides/'+ride+'/claim',headers=third).status_code,200)
    def test_account_deletion(self):
        self.join();self.event()
        self.assertEqual(self.client.request('DELETE','/account',headers=self.a,json={'password':'bad'}).status_code,401)
        self.assertEqual(self.client.request('DELETE','/account',headers=self.a,json={'password':'test-password-123'}).status_code,200)
        self.assertEqual(self.client.get('/me',headers=self.a).status_code,401)
        self.assertIsNone(self.client.get('/me',headers=self.b).json()['family_id'])
    def test_simultaneous_seat_claims(self):
        from concurrent.futures import ThreadPoolExecutor
        self.join();third=self.register('third');code=self.client.post('/invites',headers=self.a).json()['code'];self.client.post('/families/join',headers=third,json={'code':code})
        ride=self.client.post('/rides',headers=self.a,json={'event_id':self.event(),'seats':1,'route':'Field'}).json()['id']
        with ThreadPoolExecutor(max_workers=2) as pool:
            statuses=list(pool.map(lambda h:self.client.post('/rides/'+ride+'/claim',headers=h).status_code,[self.b,third]))
        self.assertEqual(sorted(statuses),[200,409])
        self.assertEqual(self.client.get('/state',headers=self.a).json()['rides'][0]['remaining'],0)
    def test_expired_invite_and_session(self):
        code=self.client.post('/invites',headers=self.a).json()['code']
        with backend.transaction() as c:c.execute('UPDATE invites SET expires=0')
        self.assertEqual(self.client.post('/families/join',headers=self.b,json={'code':code}).status_code,400)
        with backend.transaction() as c:c.execute('UPDATE sessions SET expires=0')
        self.assertEqual(self.client.get('/me',headers=self.a).status_code,401)
    def test_member_revocation(self):
        self.join();id=self.client.get('/me',headers=self.b).json()['id']
        self.assertEqual(self.client.delete('/members/'+id,headers=self.a).status_code,200)
        self.assertEqual(self.client.get('/state',headers=self.b).status_code,409)
    def test_password_reset_once_and_session_revocation(self):
        id=self.client.get('/me',headers=self.a).json()['id']
        with backend.transaction() as c:c.execute('INSERT INTO resets VALUES(?,?,?)',(backend.digest('one-time-reset-code'),id,backend.time.time()+1000))
        body={'code':'one-time-reset-code','password':'new-password-123'}
        self.assertEqual(self.client.post('/auth/reset',json=body).status_code,200)
        self.assertEqual(self.client.get('/me',headers=self.a).status_code,401)
        self.assertEqual(self.client.post('/auth/reset',json=body).status_code,400)
        self.assertEqual(self.client.post('/auth/login',json={'email':'a@example.com','password':'new-password-123'}).status_code,200)
    def test_notification_queue_and_private_content(self):
        self.join()
        self.client.post('/push-token',headers=self.b,json={'token':'ExpoPushToken[test-device]'})
        self.client.post('/messages',headers=self.a,json={'body':'Sensitive family details'})
        with backend.transaction() as c:jobs=[dict(r) for r in c.execute('SELECT * FROM outbox')]
        self.assertEqual(len(jobs),1);self.assertNotIn('Sensitive',str(jobs))
        from unittest.mock import MagicMock
        import io
        response=MagicMock();response.__enter__.return_value=io.BytesIO(b'{"data":[{"status":"ok","id":"ticket"}]}')
        with patch('app.urllib.request.urlopen',return_value=response) as send:
            backend.deliver_push();self.assertEqual(send.call_count,1)
        with backend.transaction() as c:self.assertEqual(c.execute('SELECT count(*) FROM outbox').fetchone()[0],0)
    def test_all_day_dates(self):
        raw=b'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:all-day\r\nDTSTART;VALUE=DATE:20261010\r\nSUMMARY:Game day\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n'
        feed={'id':'feed','family_id':'f','timezone':'America/New_York','athlete':'','name':'Team'}
        row=backend.parse_feed(raw,feed,datetime(2026,10,1,tzinfo=timezone.utc))[0]
        self.assertEqual(row[6],'2026-10-10');self.assertEqual(row[9],1)
    def test_ssrf(self):
        for url in ['http://calendar.bluesombrero.com/a','https://127.0.0.1/a','https://sportsengine.com.evil.com/a','https://sportsengine.com:444/a','https://x:s@ sportsengine.com/a']:
            with self.assertRaises(ValueError):backend.validate_url(url)
        with patch('app.socket.getaddrinfo',return_value=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('127.0.0.1',443))]):
            with self.assertRaises(ValueError):backend.validate_url('https://calendar.bluesombrero.com/a')
    def test_unbounded_recurrence_rejected(self):
        raw=b'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:bad\r\nDTSTART:20261001T000000Z\r\nRRULE:FREQ=SECONDLY\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n'
        with self.assertRaises(ValueError):backend.parse_feed(raw,{'id':'f','family_id':'f','timezone':'America/New_York','athlete':'','name':'Team'})
    def fixture(self,cancel=False):
        return ('BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//SIDLNE//TEST//EN\r\nBEGIN:VEVENT\r\nUID:weekly\r\nDTSTART;TZID=America/New_York:20261005T173000\r\nDTEND;TZID=America/New_York:20261005T183000\r\nRRULE:FREQ=WEEKLY;COUNT=4\r\nEXDATE;TZID=America/New_York:20261012T173000\r\nSUMMARY:Practice\r\nEND:VEVENT\r\nBEGIN:VEVENT\r\nUID:weekly\r\nRECURRENCE-ID;TZID=America/New_York:20261019T173000\r\nDTSTART;TZID=America/New_York:20261019T190000\r\nSUMMARY:Moved practice\r\n'+('STATUS:CANCELLED\r\n' if cancel else '')+'END:VEVENT\r\nEND:VCALENDAR\r\n').encode()
    def test_recurrence_exclusion_timezone(self):
        feed={'id':'feed','family_id':'family','timezone':'America/New_York','athlete':'Athlete','name':'Team'}
        rows=backend.parse_feed(self.fixture(),feed,datetime(2026,10,1,tzinfo=timezone.utc))
        self.assertEqual(len(rows),3)
        moved=next(r for r in rows if r[3]=='Moved practice');self.assertEqual(moved[6],'2026-10-19T23:00:00+00:00')
        self.assertEqual(len(backend.parse_feed(self.fixture(True),feed,datetime(2026,10,1,tzinfo=timezone.utc))),2)
    def test_feed_update_preserves_on_failure_and_removes_deleted(self):
        f=self.client.get('/me',headers=self.a).json()['family_id']
        with backend.transaction() as c:c.execute('INSERT INTO feeds VALUES(?,?,?,?,?,?,NULL,NULL)',('feed',f,'Team','Athlete','https://calendar.bluesombrero.com/a','America/New_York'))
        with patch('app.fetch_feed',return_value=self.fixture()):backend.sync_feed('feed')
        original=self.client.get('/state',headers=self.a).json();self.assertEqual(len(original['events']),3)
        with patch('app.fetch_feed',side_effect=ValueError('private token')):backend.sync_feed('feed')
        failed=self.client.get('/state',headers=self.a).json();self.assertEqual(len(failed['events']),3);self.assertNotIn('private token',str(failed));self.assertNotIn('url',failed['feeds'][0])
        with patch('app.fetch_feed',return_value=b'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nEND:VCALENDAR\r\n'):backend.sync_feed('feed')
        self.assertEqual(len(self.client.get('/state',headers=self.a).json()['events']),0)

if __name__=='__main__':unittest.main()
