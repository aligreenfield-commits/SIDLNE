"""SIDLNE shared-family API. SQLite persistence; deploy one instance per database."""
import re, smtplib
from email.message import EmailMessage
import urllib.request
import asyncio, contextlib, hashlib, hmac, http.client, ipaddress, json, os, secrets, socket, sqlite3, ssl, time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone, date
from pathlib import Path
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo
from fastapi.responses import HTMLResponse
from html import escape
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field
from icalendar import Calendar
import recurring_ical_events

DB = os.getenv('DATABASE_PATH', 'data/sidlne.sqlite3')
FEED_HOSTS = os.getenv('FEED_HOSTS', 'sportsengine.com,sportsengineplay.com,sportsengineapp.com,bluesombrero.com,sportsconnect.com').split(',')
UTC = timezone.utc

def db():
    Path(DB).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

@contextlib.contextmanager
def transaction():
    c = db()
    try:
        c.execute('BEGIN IMMEDIATE')
        yield c
        c.commit()
    except Exception:
        c.rollback(); raise
    finally:
        c.close()

def init():
    with transaction() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS families(id TEXT PRIMARY KEY, name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS members(user_id TEXT PRIMARY KEY REFERENCES users ON DELETE CASCADE, family_id TEXT REFERENCES families ON DELETE CASCADE, role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id TEXT REFERENCES users ON DELETE CASCADE, expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS invites(code TEXT PRIMARY KEY, family_id TEXT REFERENCES families ON DELETE CASCADE, expires REAL NOT NULL, uses INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS feeds(id TEXT PRIMARY KEY, family_id TEXT REFERENCES families ON DELETE CASCADE, name TEXT, athlete TEXT, url TEXT, timezone TEXT, synced REAL, error TEXT);
        CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, family_id TEXT REFERENCES families ON DELETE CASCADE, feed_id TEXT REFERENCES feeds ON DELETE CASCADE, title TEXT, athlete TEXT, team TEXT, start TEXT, end TEXT, location TEXT, all_day INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, family_id TEXT REFERENCES families ON DELETE CASCADE, user_id TEXT REFERENCES users ON DELETE CASCADE, body TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS rides(id TEXT PRIMARY KEY, family_id TEXT REFERENCES families ON DELETE CASCADE, user_id TEXT REFERENCES users ON DELETE CASCADE, event_id TEXT REFERENCES events ON DELETE CASCADE, seats INTEGER, route TEXT);
        CREATE TABLE IF NOT EXISTS reservations(ride_id TEXT REFERENCES rides ON DELETE CASCADE, user_id TEXT REFERENCES users ON DELETE CASCADE, PRIMARY KEY(ride_id,user_id));
        CREATE TABLE IF NOT EXISTS push_tokens(token TEXT PRIMARY KEY, user_id TEXT REFERENCES users ON DELETE CASCADE);
        CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY, user_id TEXT REFERENCES users ON DELETE CASCADE, body TEXT, attempts INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS resets(token TEXT PRIMARY KEY, user_id TEXT REFERENCES users ON DELETE CASCADE, expires REAL);
        CREATE TABLE IF NOT EXISTS attempts(key TEXT PRIMARY KEY, count INTEGER, until REAL);
        CREATE INDEX IF NOT EXISTS events_family ON events(family_id,start);
        CREATE INDEX IF NOT EXISTS messages_family ON messages(family_id,created);
        ''')
        c.execute('PRAGMA journal_mode=WAL')

def uid(): return secrets.token_hex(16)
def digest(s): return hashlib.sha256(s.encode()).hexdigest()
def password_hash(s, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + ':' + hashlib.scrypt(s.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1).hex()

def throttle(key, limit=20):
    with transaction() as c:
        now = time.time()
        c.execute('DELETE FROM attempts WHERE until < ?', (now,))
        row = c.execute('SELECT * FROM attempts WHERE key=?', (key,)).fetchone()
        if row and row['count'] >= limit: raise HTTPException(429, 'Too many attempts. Try again in 15 minutes.')
        c.execute('INSERT INTO attempts VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1', (key,now+900))

def session(c, user_id):
    token = secrets.token_urlsafe(32)
    c.execute('DELETE FROM sessions WHERE expires < ?', (time.time(),))
    c.execute('INSERT INTO sessions VALUES(?,?,?)', (digest(token),user_id,time.time()+30*86400))
    return {'token': token}

def current(authorization: str = Header(default='')):
    token = authorization.removeprefix('Bearer ')
    with contextlib.closing(db()) as c:
        row = c.execute('SELECT u.id,u.name,u.email,m.family_id,m.role FROM sessions s JOIN users u ON u.id=s.user_id LEFT JOIN members m ON m.user_id=u.id WHERE s.token=? AND s.expires>?', (digest(token),time.time())).fetchone()
    if not row: raise HTTPException(401,'Please sign in again.')
    return dict(row)

def family(u=Depends(current)):
    if not u['family_id']: raise HTTPException(409,'Create or join a family first.')
    return u

def owner(u):
    if u['role'] != 'owner': raise HTTPException(403,'Only the family owner can do that.')

class Credentials(BaseModel):
    email: str = Field(min_length=3,max_length=254)
    password: str = Field(min_length=10,max_length=128)
    name: str = Field(default='',max_length=80)
class FamilyName(BaseModel):
    name: str = Field(min_length=1,max_length=80)
class Join(BaseModel):
    code: str = Field(min_length=8,max_length=64)
class Feed(BaseModel):
    name: str = Field(min_length=1,max_length=80)
    athlete: str = Field(default='',max_length=80)
    url: str = Field(max_length=2048)
    timezone: str = 'America/New_York'
class Event(BaseModel):
    title: str = Field(min_length=1,max_length=180)
    athlete: str = Field(default='',max_length=80)
    team: str = Field(default='Family',max_length=80)
    start: datetime
    end: datetime | None = None
    location: str = Field(default='',max_length=300)
class Message(BaseModel):
    body: str = Field(min_length=1,max_length=2000)
class Ride(BaseModel):
    event_id: str
    seats: int = Field(ge=1,le=8)
    route: str = Field(min_length=1,max_length=180)
class PushToken(BaseModel):
    token: str = Field(max_length=200)
class EmailAddress(BaseModel):
    email: str = Field(min_length=3,max_length=254)
class ResetPassword(BaseModel):
    code: str = Field(min_length=16,max_length=100)
    password: str = Field(min_length=10,max_length=128)
class DeleteAccount(BaseModel):
    password: str

# Strict host allowlist, public-IP checks, pinned DNS and TLS hostname verification.
# No redirects: a redirected feed must be added using its final approved URL.
def validate_url(url):
    if url.startswith('webcal://'): url = 'https://' + url[9:]
    p = urlsplit(url)
    host = (p.hostname or '').lower()
    if p.scheme != 'https' or p.port not in (None,443) or p.username or p.password or p.fragment:
        raise ValueError('Use an HTTPS or webcal calendar subscription link.')
    if not any(host == h.strip() or host.endswith('.'+h.strip()) for h in FEED_HOSTS if h.strip()):
        raise ValueError('This calendar provider is not enabled. Ask support to enable its domain.')
    addresses = socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
        raise ValueError('Calendar host must resolve to public internet addresses.')
    return url, host, addresses[0][4][0]

class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, ip):
        super().__init__(host,timeout=15,context=ssl.create_default_context()); self.ip=ip
    def connect(self):
        raw = socket.create_connection((self.ip,443),self.timeout)
        self.sock = self._context.wrap_socket(raw,server_hostname=self.host)

def fetch_feed(url):
    url, host, ip = validate_url(url)
    p = urlsplit(url); conn = PinnedHTTPS(host,ip)
    try:
        conn.request('GET',p.path + ('?'+p.query if p.query else ''),headers={'User-Agent':'SIDLNE/1.1','Accept':'text/calendar'})
        response = conn.getresponse()
        if response.status != 200: raise ValueError('Calendar provider did not return a calendar (HTTP %s).' % response.status)
        raw = response.read(2*1024*1024+1)
        if len(raw)>2*1024*1024: raise ValueError('Calendar exceeds the 2 MB limit.')
        return raw
    finally: conn.close()

def parse_feed(raw, feed, now=None):
    cal = Calendar.from_ical(raw)
    if cal.name != 'VCALENDAR': raise ValueError('The link did not return an iCalendar file.')
    budget=0
    for component in cal.walk('VEVENT'):
        rule=component.get('RRULE')
        estimate=1
        if rule:
            if str(rule.get('FREQ',[''])[0]).upper() in ('SECONDLY','MINUTELY','HOURLY'):
                raise ValueError('High-frequency calendar recurrence is unsupported.')
            estimate=400
            for field in ('BYHOUR','BYMINUTE','BYSECOND'):
                estimate*=max(1,len(rule.get(field,[])))
            if rule.get('COUNT'):estimate=min(estimate,int(rule['COUNT'][0]))
        budget+=estimate
        if budget>10000:raise ValueError('Calendar recurrence expansion exceeds the safe limit.')
    zone = ZoneInfo(feed['timezone']); now = now or datetime.now(UTC)
    expanded = recurring_ical_events.of(cal).between(now-timedelta(days=30),now+timedelta(days=365))
    if len(expanded)>5000: raise ValueError('Calendar has too many events.')
    results = {}
    def iso(value):
        if not isinstance(value,datetime): value = datetime.combine(value,datetime.min.time())
        if value.tzinfo is None: value=value.replace(tzinfo=zone)
        return value.astimezone(UTC).isoformat()
    for event in expanded:
        if str(event.get('STATUS','')).upper() == 'CANCELLED': continue
        start = event.decoded('DTSTART'); end = event.decoded('DTEND',None)
        identity = str(event.get('UID',''))
        if not identity: raise ValueError('Calendar event is missing a UID.')
        recurrence = event.decoded('RECURRENCE-ID',None)
        # The original recurrence identity survives an exception moving the start.
        key = digest(feed['id'] + ':' + identity + ':' + (iso(recurrence) if recurrence is not None else 'single'))
        results[key] = (key,feed['family_id'],feed['id'],str(event.get('SUMMARY','Untitled'))[:180],feed['athlete'],feed['name'],iso(start) if isinstance(start,datetime) else start.isoformat(),(iso(end) if isinstance(end,datetime) else end.isoformat()) if end else None,str(event.get('LOCATION',''))[:300],int(not isinstance(start,datetime)))
    return list(results.values())

_sync_lock = __import__('threading').Lock()
def sync_feed(feed_id):
    with _sync_lock:
        with contextlib.closing(db()) as c:
            f = c.execute('SELECT * FROM feeds WHERE id=?',(feed_id,)).fetchone()
        if not f: return
        f=dict(f)
        try:
            rows=parse_feed(fetch_feed(f['url']),f)
            with transaction() as c:
                if not c.execute('SELECT 1 FROM feeds WHERE id=?',(feed_id,)).fetchone(): return
                old_rows=[tuple(r) for r in c.execute('SELECT * FROM events WHERE feed_id=?',(feed_id,))]
                existing = {r[0] for r in old_rows}
                changed=set(old_rows)!=set(rows)
                incoming = {r[0] for r in rows}
                for r in rows:
                    c.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,start=excluded.start,end=excluded.end,location=excluded.location,all_day=excluded.all_day',r)
                for key in existing-incoming: c.execute('DELETE FROM events WHERE id=?',(key,))
                c.execute('UPDATE feeds SET synced=?,error=NULL WHERE id=?',(time.time(),feed_id))
                if changed and f['synced']: notify(c,f['family_id'],'Your family calendar has changed. Open SIDLNE for the latest schedule.')
        except Exception:
            # Never expose tokens, fetched URLs, or exception strings to clients/logs.
            with transaction() as c:
                c.execute('UPDATE feeds SET error=? WHERE id=?',('Could not update this calendar. Previous events are retained. Check the subscription link or try again later.',feed_id))

async def worker():
    while True:
        with contextlib.closing(db()) as c: ids=[r['id'] for r in c.execute('SELECT id FROM feeds')]
        for id in ids: await asyncio.to_thread(sync_feed,id)
        # Deliver chat/ride updates every 10s without waiting for next feed sweep.
        for _ in range(max(1,int(os.getenv('SYNC_SECONDS','900'))//10)):
            await asyncio.to_thread(deliver_push)
            await asyncio.sleep(10)

@asynccontextmanager
async def lifespan(app):
    init(); task=asyncio.create_task(worker())
    yield
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError): await task

app=FastAPI(title='SIDLNE API',version='1.1.0',lifespan=lifespan,docs_url=None,redoc_url=None)

@app.middleware('http')
async def limits(request: Request, call_next):
    if int(request.headers.get('content-length','0') or '0') > 16384:
        from fastapi.responses import JSONResponse
        return JSONResponse({'detail':'Request too large'},status_code=413)
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    return response

@app.get('/health')
def health(): return {'status':'ok','version':'1.1.0'}

@app.post('/auth/register')
def register(data: Credentials, request: Request):
    throttle('register:'+request.client.host,10)
    email=data.email.strip().lower()
    if '@' not in email or not data.name.strip(): raise HTTPException(400,'Enter your name and email.')
    try:
        with transaction() as c:
            id=uid(); c.execute('INSERT INTO users VALUES(?,?,?,?)',(id,email,data.name.strip(),password_hash(data.password)))
            return session(c,id)
    except sqlite3.IntegrityError: raise HTTPException(409,'That email is already registered. Sign in instead.')

@app.post('/auth/login')
def login(data: Credentials, request: Request):
    throttle('login:'+digest(data.email.strip().lower()))
    throttle('login-ip:'+request.client.host,200)
    with transaction() as c:
        u=c.execute('SELECT * FROM users WHERE email=?',(data.email.strip().lower(),)).fetchone()
        stored=u['password'] if u else password_hash('invalid-password')
        if not hmac.compare_digest(stored,password_hash(data.password,stored.split(':')[0])) or not u:
            raise HTTPException(401,'Email or password is incorrect.')
        return session(c,u['id'])

@app.post('/auth/logout')
def logout(u=Depends(current), authorization: str=Header()):
    with transaction() as c:
        c.execute('DELETE FROM sessions WHERE token=?',(digest(authorization.removeprefix('Bearer ')),))
        c.execute('DELETE FROM push_tokens WHERE user_id=?',(u['id'],))
    return {'ok':True}

@app.get('/me')
def me(u=Depends(current)): return u

@app.post('/families')
def create_family(data: FamilyName,u=Depends(current)):
    with transaction() as c:
        if c.execute('SELECT 1 FROM members WHERE user_id=?',(u['id'],)).fetchone(): raise HTTPException(409,'You already belong to a family.')
        id=uid(); c.execute('INSERT INTO families VALUES(?,?)',(id,data.name.strip()))
        c.execute('INSERT INTO members VALUES(?,?,?)',(u['id'],id,'owner'))
    return {'id':id}

@app.post('/invites')
def invite(u=Depends(family)):
    owner(u)
    with transaction() as c:
        c.execute('DELETE FROM invites WHERE family_id=?',(u['family_id'],))
        code=secrets.token_hex(8).upper()
        c.execute('INSERT INTO invites VALUES(?,?,?,0)',(digest(code),u['family_id'],time.time()+7*86400))
    return {'code':code,'expires_in_days':7}

@app.post('/families/join')
def join(data: Join,u=Depends(current)):
    throttle('join:'+u['id'])
    with transaction() as c:
        if c.execute('SELECT 1 FROM members WHERE user_id=?',(u['id'],)).fetchone(): raise HTTPException(409,'You already belong to a family.')
        i=c.execute('SELECT * FROM invites WHERE code=? AND expires>? AND uses<10',(digest(data.code.strip().upper()),time.time())).fetchone()
        if not i: raise HTTPException(400,'Invite is invalid, expired, or full. Ask for a new code.')
        c.execute('INSERT INTO members VALUES(?,?,?)',(u['id'],i['family_id'],'member'))
        c.execute('UPDATE invites SET uses=uses+1 WHERE code=?',(i['code'],))
    return {'ok':True}

@app.get('/state')
def state(u=Depends(family)):
    f=u['family_id']
    with contextlib.closing(db()) as c:
        family_name=c.execute('SELECT name FROM families WHERE id=?',(f,)).fetchone()['name']
        events=[dict(r) for r in c.execute('SELECT * FROM events WHERE family_id=? ORDER BY start',(f,))]
        feeds=[dict(r) for r in c.execute('SELECT id,name,athlete,timezone,synced,error FROM feeds WHERE family_id=?',(f,))]
        members=[dict(r) for r in c.execute('SELECT u.id,u.name,m.role FROM members m JOIN users u ON u.id=m.user_id WHERE family_id=?',(f,))]
        messages=[dict(r) for r in c.execute('SELECT m.*,u.name author FROM messages m JOIN users u ON u.id=m.user_id WHERE family_id=? ORDER BY created DESC LIMIT 300',(f,))][::-1]
        rides=[dict(r) for r in c.execute('SELECT r.*,u.name driver,e.title event, (SELECT count(*) FROM reservations WHERE ride_id=r.id) reserved FROM rides r JOIN users u ON u.id=r.user_id JOIN events e ON e.id=r.event_id WHERE r.family_id=?',(f,))]
        for r in rides:
            r['remaining']=r['seats']-r['reserved']
            r['claimed']=bool(c.execute('SELECT 1 FROM reservations WHERE ride_id=? AND user_id=?',(r['id'],u['id'])).fetchone())
    return {'family':family_name,'events':events,'feeds':feeds,'members':members,'messages':messages,'rides':rides}

@app.post('/feeds')
def add_feed(data: Feed,u=Depends(family)):
    owner(u); throttle('feed-add:'+u['id'],20)
    try: url,_,_=validate_url(data.url); ZoneInfo(data.timezone)
    except Exception: raise HTTPException(400,'Use a supported public calendar subscription link and a valid time zone.')
    with transaction() as c:
        if c.execute('SELECT count(*) FROM feeds WHERE family_id=?',(u['family_id'],)).fetchone()[0]>=20: raise HTTPException(400,'Maximum 20 calendars per family.')
        if c.execute('SELECT 1 FROM feeds WHERE family_id=? AND url=?',(u['family_id'],url)).fetchone(): raise HTTPException(409,'This calendar is already connected.')
        id=uid(); c.execute('INSERT INTO feeds VALUES(?,?,?,?,?,?,NULL,NULL)',(id,u['family_id'],data.name,data.athlete,url,data.timezone))
    sync_feed(id)
    return {'id':id}

@app.post('/feeds/{id}/sync')
def sync(id: str,u=Depends(family)):
    owner(u); throttle('sync:'+u['id'],30)
    with contextlib.closing(db()) as c:
        if not c.execute('SELECT 1 FROM feeds WHERE id=? AND family_id=?',(id,u['family_id'])).fetchone(): raise HTTPException(404,'Calendar not found.')
    sync_feed(id); return {'ok':True}

@app.delete('/feeds/{id}')
def remove_feed(id: str,u=Depends(family)):
    owner(u)
    with transaction() as c: c.execute('DELETE FROM feeds WHERE id=? AND family_id=?',(id,u['family_id']))
    return {'ok':True}

@app.post('/events')
def add_event(data: Event,u=Depends(family)):
    if not data.start.tzinfo or (data.end and (not data.end.tzinfo or data.end<=data.start)): raise HTTPException(400,'Use a valid event time with a time zone.')
    with transaction() as c:
        id=uid(); c.execute('INSERT INTO events VALUES(?,?,NULL,?,?,?,?,?,?,0)',(id,u['family_id'],data.title,data.athlete,data.team,data.start.astimezone(UTC).isoformat(),data.end.astimezone(UTC).isoformat() if data.end else None,data.location))
        notify(c,u['family_id'],'A new family event was added. Open SIDLNE for details.',u['id'])
    return {'id':id}

@app.delete('/events/{id}')
def remove_event(id: str,u=Depends(family)):
    owner(u)
    with transaction() as c: c.execute('DELETE FROM events WHERE id=? AND family_id=? AND feed_id IS NULL',(id,u['family_id']))
    return {'ok':True}

@app.post('/messages')
def message(data: Message,u=Depends(family)):
    throttle('messages:'+u['id'],100)
    if not data.body.strip(): raise HTTPException(400,'Write a message first.')
    with transaction() as c:
        id=uid(); c.execute('INSERT INTO messages VALUES(?,?,?,?,?)',(id,u['family_id'],u['id'],data.body.strip(),time.time()))
        notify(c,u['family_id'],'You have a new family message.',u['id'])
    return {'id':id}

@app.post('/rides')
def ride(data: Ride,u=Depends(family)):
    with transaction() as c:
        if not c.execute('SELECT 1 FROM events WHERE id=? AND family_id=?',(data.event_id,u['family_id'])).fetchone(): raise HTTPException(404,'Event not found.')
        id=uid(); c.execute('INSERT INTO rides VALUES(?,?,?,?,?,?)',(id,u['family_id'],u['id'],data.event_id,data.seats,data.route))
        notify(c,u['family_id'],'A family member offered a ride. Open SIDLNE to reserve a seat.',u['id'])
    return {'id':id}

@app.post('/rides/{id}/claim')
def claim(id: str,u=Depends(family)):
    with transaction() as c:
        r=c.execute('SELECT * FROM rides WHERE id=? AND family_id=?',(id,u['family_id'])).fetchone()
        if not r: raise HTTPException(404,'Ride not found.')
        if r['user_id']==u['id']: raise HTTPException(400,'You are already the driver.')
        if c.execute('SELECT 1 FROM reservations WHERE ride_id=? AND user_id=?',(id,u['id'])).fetchone(): return {'ok':True}
        if c.execute('SELECT count(*) FROM reservations WHERE ride_id=?',(id,)).fetchone()[0]>=r['seats']: raise HTTPException(409,'This ride is full.')
        c.execute('INSERT INTO reservations VALUES(?,?)',(id,u['id']))
    return {'ok':True}

@app.delete('/rides/{id}/claim')
def unclaim(id: str,u=Depends(family)):
    with transaction() as c:
        if not c.execute('SELECT 1 FROM rides WHERE id=? AND family_id=?',(id,u['family_id'])).fetchone(): raise HTTPException(404,'Ride not found.')
        c.execute('DELETE FROM reservations WHERE ride_id=? AND user_id=?',(id,u['id']))
    return {'ok':True}

@app.delete('/rides/{id}')
def delete_ride(id: str,u=Depends(family)):
    with transaction() as c: c.execute('DELETE FROM rides WHERE id=? AND family_id=? AND user_id=?',(id,u['family_id'],u['id']))
    return {'ok':True}

@app.delete('/account')
def delete_account(data: DeleteAccount,u=Depends(current)):
    with transaction() as c:
        stored=c.execute('SELECT password FROM users WHERE id=?',(u['id'],)).fetchone()[0]
        if not hmac.compare_digest(stored,password_hash(data.password,stored.split(':')[0])): raise HTTPException(401,'Password is incorrect.')
        if u['role']=='owner': c.execute('DELETE FROM families WHERE id=?',(u['family_id'],))
        c.execute('DELETE FROM users WHERE id=?',(u['id'],))
    return {'ok':True}


def notify(c,family_id,body,exclude=None):
    for row in c.execute('SELECT user_id FROM members WHERE family_id=?',(family_id,)).fetchall():
        if row['user_id']!=exclude:
            c.execute('INSERT INTO outbox(id,user_id,body) VALUES(?,?,?)',(uid(),row['user_id'],body))

def deliver_push():
    with contextlib.closing(db()) as c:
        jobs=[dict(r) for r in c.execute('SELECT * FROM outbox LIMIT 50')]
    for job in jobs:
        with contextlib.closing(db()) as c: tokens=[r['token'] for r in c.execute('SELECT token FROM push_tokens WHERE user_id=?',(job['user_id'],))]
        try:
            if tokens:
                data=[{'to':t,'title':'SIDLNE','body':job['body'],'sound':'default'} for t in tokens]
                headers={'Content-Type':'application/json'}
                if os.getenv('EXPO_ACCESS_TOKEN'): headers['Authorization']='Bearer '+os.environ['EXPO_ACCESS_TOKEN']
                req=urllib.request.Request('https://exp.host/--/api/v2/push/send',data=json.dumps(data).encode(),headers=headers)
                with urllib.request.urlopen(req,timeout=15) as response: result=json.load(response)
                for token,ticket in zip(tokens,result.get('data',[])):
                    if ticket.get('status')=='error':
                        if ticket.get('details',{}).get('error')=='DeviceNotRegistered':
                            with transaction() as c:c.execute('DELETE FROM push_tokens WHERE token=?',(token,))
                        else:raise ValueError('Push service rejected a message')
            with transaction() as c:c.execute('DELETE FROM outbox WHERE id=?',(job['id'],))
        except Exception:
            with transaction() as c:
                if job['attempts']>=5:c.execute('DELETE FROM outbox WHERE id=?',(job['id'],))
                else:c.execute('UPDATE outbox SET attempts=attempts+1 WHERE id=?',(job['id'],))

@app.post('/push-token')
def push_token(data: PushToken,u=Depends(family)):
    if not re.fullmatch(r'(ExponentPushToken|ExpoPushToken)\[[A-Za-z0-9_-]+\]',data.token):raise HTTPException(400,'Invalid notification token.')
    with transaction() as c:
        count=c.execute('SELECT count(*) FROM push_tokens WHERE user_id=?',(u['id'],)).fetchone()[0]
        if count>=10:c.execute('DELETE FROM push_tokens WHERE user_id=?',(u['id'],))
        c.execute('INSERT INTO push_tokens VALUES(?,?) ON CONFLICT(token) DO UPDATE SET user_id=excluded.user_id',(data.token,u['id']))
    return {'ok':True}

@app.delete('/push-token')
def remove_push_token(data: PushToken,u=Depends(current)):
    with transaction() as c:c.execute('DELETE FROM push_tokens WHERE token=? AND user_id=?',(data.token,u['id']))
    return {'ok':True}

@app.delete('/members/{id}')
def remove_member(id: str,u=Depends(family)):
    owner(u)
    if id==u['id']:raise HTTPException(400,'Use Delete my account to remove the family owner.')
    with transaction() as c:
        if not c.execute('SELECT 1 FROM members WHERE user_id=? AND family_id=?',(id,u['family_id'])).fetchone():raise HTTPException(404,'Member not found.')
        c.execute('DELETE FROM reservations WHERE user_id=?',(id,))
        c.execute('DELETE FROM rides WHERE user_id=? AND family_id=?',(id,u['family_id']))
        c.execute('DELETE FROM outbox WHERE user_id=?',(id,))
        c.execute('DELETE FROM members WHERE user_id=?',(id,))
        # Revoke outstanding codes so the removed person cannot rejoin.
        c.execute('DELETE FROM invites WHERE family_id=?',(u['family_id'],))
    return {'ok':True}

@app.post('/auth/forgot')
def forgot(data: EmailAddress,request: Request):
    throttle('forgot:'+request.client.host,5)
    if not os.getenv('SMTP_HOST') or not os.getenv('SMTP_FROM'):
        raise HTTPException(503,'Email recovery is not configured yet. Contact support.')
    with transaction() as c:
        user=c.execute('SELECT id FROM users WHERE email=?',(data.email.strip().lower(),)).fetchone()
        if user:
            code=secrets.token_urlsafe(24)
            c.execute('DELETE FROM resets WHERE user_id=?',(user['id'],))
            c.execute('INSERT INTO resets VALUES(?,?,?)',(digest(code),user['id'],time.time()+1800))
    if user:
        message=EmailMessage();message['Subject']='Your SIDLNE password reset code';message['From']=os.environ['SMTP_FROM'];message['To']=data.email.strip().lower()
        message.set_content('Open SIDLNE, choose Reset password, and paste this one-time code:\n\n'+code+'\n\nExpires in 30 minutes. Ignore this email if you did not request it.')
        try:
            with smtplib.SMTP(os.environ['SMTP_HOST'],int(os.getenv('SMTP_PORT','587')),timeout=15) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                if os.getenv('SMTP_USER'):smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
                smtp.send_message(message)
        except Exception: raise HTTPException(503,'Recovery email could not be sent. Try again later.')
    return {'ok':True,'message':'If an account exists for this email, a reset code has been sent.'}

@app.post('/auth/reset')
def reset_password(data: ResetPassword,request: Request):
    throttle('reset:'+request.client.host,10)
    with transaction() as c:
        row=c.execute('SELECT * FROM resets WHERE token=? AND expires>?',(digest(data.code.strip()),time.time())).fetchone()
        if not row:raise HTTPException(400,'Reset code is invalid or expired.')
        c.execute('UPDATE users SET password=? WHERE id=?',(password_hash(data.password),row['user_id']))
        c.execute('DELETE FROM resets WHERE user_id=?',(row['user_id'],))
        c.execute('DELETE FROM sessions WHERE user_id=?',(row['user_id'],))
        c.execute('DELETE FROM push_tokens WHERE user_id=?',(row['user_id'],))
    return {'ok':True}


@app.get('/privacy',response_class=HTMLResponse)
def privacy():
    return """<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SIDLNE Privacy</title><main style="max-width:720px;margin:40px auto;padding:24px;font:17px/1.6 system-ui"><h1>SIDLNE Privacy</h1><p>Effective October 6, 2026. Operated by SIDLNE LLC.</p><p>SIDLNE stores adult account names and email addresses, password hashes, family memberships, calendar subscription links, imported schedules, messages, rides, and seat reservations. Your account session is stored securely on your phone.</p><p>Family members can see each other’s names, schedules, messages, and rides. Subscription links are used by the server to import calendars and are not returned to other members. Family owners can invite or remove members.</p><p>If you enable notifications, your device’s push token and generic notifications are processed through Expo and Apple. Password recovery email is processed through our configured email provider. Hosting providers process stored data to operate the service. We do not sell your data or include advertising or analytics trackers.</p><p>Data remains until deleted. Delete your account in Family &amp; teams. Deleting a family owner’s account removes the entire family’s stored calendars, events, messages, and rides. Other members keep their accounts. Device settings control notification permissions.</p><p>SIDLNE accounts are intended for adults managing family schedules. Avoid unnecessary sensitive details about children in messages and events. Changes to this policy will appear here.</p><p>For privacy questions, use <a href="/support">SIDLNE Support</a>.</p></main></html>"""

@app.get('/support',response_class=HTMLResponse)
def support():
    contact=escape(os.getenv('SUPPORT_EMAIL',''))
    detail=('Contact '+contact+'.') if contact else 'Support contact is not configured yet. The operator must configure support before public launch.'
    return '<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SIDLNE Support</title><main style="max-width:720px;margin:40px auto;padding:24px;font:17px/1.6 system-ui"><h1>SIDLNE Support</h1><p>'+detail+'</p><p>To connect a calendar, paste its subscription link into Family &amp; teams → Connect calendar. The family owner manages invites and calendars. For password help, use Reset on the sign-in screen.</p></main></html>'
