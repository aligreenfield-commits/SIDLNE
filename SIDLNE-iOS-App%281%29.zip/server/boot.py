"""Initialize mounted disk permissions before dropping all root privileges."""
import os
from pathlib import Path
path=Path(os.getenv('DATABASE_PATH','/data/sidlne.sqlite3')).parent
path.mkdir(parents=True,exist_ok=True)
if os.getuid()==0:
    os.chown(path,10001,10001);os.chmod(path,0o700)
    for file in path.glob('sidlne.sqlite3*'):os.chown(file,10001,10001)
    os.setgroups([]);os.setgid(10001);os.setuid(10001)
os.execvp('python',['python','-m','uvicorn','app:app','--host','0.0.0.0','--port',os.getenv('PORT','8000'),'--no-access-log','--no-proxy-headers'])
